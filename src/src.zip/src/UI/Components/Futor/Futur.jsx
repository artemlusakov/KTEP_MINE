import React from 'react';
import s from './Futor.module.css'

const Futur = () => {
    return (
        <div>
            <div>
                Наши сотсети
                <div className={s.Sotseti}>
                    <img src="" alt=""/>
                    <img src="" alt=""/>
                    <img src="" alt=""/>
                </div>
            </div>
        </div>
    );
};

export default Futur;