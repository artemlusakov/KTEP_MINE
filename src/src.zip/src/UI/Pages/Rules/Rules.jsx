import React from 'react';
import s from './Rules.module.css'
const Rules = () => {
    return (
        <div className={s.Rules}>
            <div className={s.Bloc}>
                <div className={s.Bloc_name}>
                <img src="https://cdn-icons-png.flaticon.com/512/528/528095.png" alt="world"/>
                <h1>World</h1>
                </div>

                <div className={s.Bloc_text}>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque laborum sit. Dolorem, quos, reprehenderit? Ab amet cum dolores numquam repellendus suscipit unde ut. Aspernatur atque beatae consequuntur cupiditate deleniti, dicta dolorum enim est et exercitationem facere facilis laboriosam libero maxime natus neque pariatur perspiciatis quidem temporibus voluptatem. Aliquid amet aperiam asperiores atque commodi consequuntur cum debitis doloremque dolorum ducimus eligendi eos et eum eveniet facere id ipsam ipsum iusto magnam magni minima modi molestiae nobis nulla obcaecati officia quae quas quidem sapiente suscipit, ullam unde velit voluptates. Alias architecto enim
                    molestias nesciunt non officiis optio quaerat quidem quo tempore?
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque laborum sit. Dolorem, quos, reprehenderit? Ab amet cum dolores numquam repellendus suscipit unde ut. Aspernatur atque beatae consequuntur cupiditate deleniti, dicta dolorum enim est et exercitationem facere facilis laboriosam libero maxime natus neque pariatur perspiciatis quidem temporibus voluptatem. Aliquid amet aperiam asperiores atque commodi consequuntur cum debitis doloremque dolorum ducimus eligendi eos et eum eveniet facere id ipsam ipsum iusto magnam magni minima modi molestiae nobis nulla obcaecati officia quae quas quidem sapiente suscipit, ullam unde velit voluptates. Alias architecto enim
                </div>
            </div>

            <div className={s.Bloc}>
                <div className={s.Bloc_name}>
                    <img src="https://img.icons8.com/office/512/minecraft-main-character.png" alt="world"/>
                    <h1>User</h1>
                </div>

                <div className={s.Bloc_text}>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque laborum sit. Dolorem, quos, reprehenderit? Ab amet cum dolores numquam repellendus suscipit unde ut. Aspernatur atque beatae consequuntur cupiditate deleniti, dicta dolorum enim est et exercitationem facere facilis laboriosam libero maxime natus neque pariatur perspiciatis quidem temporibus voluptatem. Aliquid amet aperiam asperiores atque commodi consequuntur cum debitis doloremque dolorum ducimus eligendi eos et eum eveniet facere id ipsam ipsum iusto magnam magni minima modi molestiae nobis nulla obcaecati officia quae quas quidem sapiente suscipit, ullam unde velit voluptates. Alias architecto enim
                    molestias nesciunt non officiis optio quaerat quidem quo tempore?
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque laborum sit. Dolorem, quos, reprehenderit? Ab amet cum dolores numquam repellendus suscipit unde ut. Aspernatur atque beatae consequuntur cupiditate deleniti, dicta dolorum enim est et exercitationem facere facilis laboriosam libero maxime natus neque pariatur perspiciatis quidem temporibus voluptatem. Aliquid amet aperiam asperiores atque commodi consequuntur cum debitis doloremque dolorum ducimus eligendi eos et eum eveniet facere id ipsam ipsum iusto magnam magni minima modi molestiae nobis nulla obcaecati officia quae quas quidem sapiente suscipit, ullam unde velit voluptates. Alias architecto enim
                </div>
            </div>

            <div className={s.Bloc}>
                <div className={s.Bloc_name}>
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWkdt4rygA3YB8K4riJ9dL3kFXWpWf_8avKA&usqp=CAU" alt="world"/>
                    <h1>admins</h1>
                </div>

                <div className={s.Bloc_text}>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque laborum sit. Dolorem, quos, reprehenderit? Ab amet cum dolores numquam repellendus suscipit unde ut. Aspernatur atque beatae consequuntur cupiditate deleniti, dicta dolorum enim est et exercitationem facere facilis laboriosam libero maxime natus neque pariatur perspiciatis quidem temporibus voluptatem. Aliquid amet aperiam asperiores atque commodi consequuntur cum debitis doloremque dolorum ducimus eligendi eos et eum eveniet facere id ipsam ipsum iusto magnam magni minima modi molestiae nobis nulla obcaecati officia quae quas quidem sapiente suscipit, ullam unde velit voluptates. Alias architecto enim
                    molestias nesciunt non officiis optio quaerat quidem quo tempore?
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque laborum sit. Dolorem, quos, reprehenderit? Ab amet cum dolores numquam repellendus suscipit unde ut. Aspernatur atque beatae consequuntur cupiditate deleniti, dicta dolorum enim est et exercitationem facere facilis laboriosam libero maxime natus neque pariatur perspiciatis quidem temporibus voluptatem. Aliquid amet aperiam asperiores atque commodi consequuntur cum debitis doloremque dolorum ducimus eligendi eos et eum eveniet facere id ipsam ipsum iusto magnam magni minima modi molestiae nobis nulla obcaecati officia quae quas quidem sapiente suscipit, ullam unde velit voluptates. Alias architecto enim
                </div>
            </div>
        </div>
    );
};

export default Rules;