import React from "react";
import s from './Coments.module.css'
import Coment from './Components/Coments/Coments'

const Coments = () => {
    return (
        <div>
            <section className={s.Coments_Head}>
                <div className={s.Coments_Head_text}>Отзывы от Игроков</div>

            </section>

            <section className={s.Coments_Content}>
                <Coment Nik='lol' Coments='ahahahhahahhahah'/>
            </section>
        </div>
    );
};

export default Coments;