import React from 'react';
import s from './Coments.module.css'
import Simple from "../Simple_raiting/Simple";


const Coment = (props) => {
    return (
        <article className={s.Coments_All}>
            <div className={s.Profil}>
                    <img src={props.src} alt="" />
                <div className={s.Raiting}>
                    {props.Nik}

                    <div className={s.Simple_rating}>
                        <div className={s.Simple_raiting_items}>
                            <Simple value={5}/>
                            <Simple value={4}/>
                            <Simple value={3}/>
                            <Simple value={2}/>
                            <Simple value={1}/>
                         </div>
                    </div>
                </div>
            </div>

            <p className={s.Coments_text}>

                {props.Coments}
            </p>
        </article>

    );
};

export default Coment;