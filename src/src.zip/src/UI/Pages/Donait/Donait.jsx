import React, {useState} from 'react';
import BoxDonait from './Components/BoxDonait/BoxDonait';
import s from './Donait.module.css';


const Donait = (props) => {
    const [modalActive, setModalActive] = useState( false)
    return (
        <div>
            <section className={s.headline}>
   Лутший Донат
</section>

<section className={s.Donaite}>
    <BoxDonait
        active={props.modalActive}
        setActive={props.setModalActive}
        name='Lol'
        prise='100'/>
    <BoxDonait name='Vip' prise='100'/>
    <BoxDonait name='helper' prise='100'/>
    <BoxDonait name='builder' prise='100'/>
    <BoxDonait name='seraphin' prise='100'/>
    <BoxDonait name='adamai' prise='100'/>
    <BoxDonait name='trol' prise='100'/>
    <BoxDonait name='dreame' prise='100'/>
    <BoxDonait name='admin' prise='100'/>
    <BoxDonait name='Soruk' prise='100'/>

</section>

        </div>

    );
};

export default Donait;