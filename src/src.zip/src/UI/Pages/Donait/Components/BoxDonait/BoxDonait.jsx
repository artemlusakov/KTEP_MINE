import React from 'react';
import s from './BoxDonait.module.css'
import Modal from "../../../../Components/Modal/Modal";

const BoxDonait = (props) => {

    return (
    <div className={s.Box}>
        <a href="#"><img src={props.src} alt="IMG Box"/></a>
            <h2>{props.name}</h2>
        <div className={s.Prise}>
            <Modal
                active={props.modalActive}
                setActive={props.setModalActive}
            />
            <h3>{props.prise}р</h3> <button onClick={()=> props.setModalActive(true)}>купить</button>
        </div>
    </div>
  

    );
};

export default BoxDonait;