import React, {useState} from 'react';
import Card from "./Components/Card/Card";
import s from './Modes.module.css'


const Modes = () => {
    const [modalActive, setModalActive] = useState( false)
    return (
        <div>
            <div  className={s.Modes_content}>
            <Card
                modalActive={modalActive}
                setModalActive={setModalActive}
                img={'https://img.freepik.com/free-icon/globe_318-436669.jpg'}
                name={'Выживание'}
                text={"Ttex text text"}/>

            <Card
                modalActive={modalActive}
                setModalActive={setModalActive}
                img={'https://img.freepik.com/free-icon/globe_318-436669.jpg'}
                name={'Выживание'}
                text={"Ttex text text"}/>

            <Card
                modalActive={modalActive}
                setModalActive={setModalActive}
                img={'https://img.freepik.com/free-icon/globe_318-436669.jpg'}
                name={'Выживание'}
                text={"Ttex text text"}/>

            <Card
                modalActive={modalActive}
                setModalActive={setModalActive}
                img={'https://img.freepik.com/free-icon/globe_318-436669.jpg'}
                name={'Выживание'}
                text={"Ttex text text"}/>

            </div>
            </div>





    );
};

export default Modes;